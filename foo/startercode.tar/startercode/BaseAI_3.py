class BaseAI:
    def getMove(self, grid):
        pass
